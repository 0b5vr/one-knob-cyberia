# one-knob-cyberia

Appeared in NOVA 2022 Wild Compo

4KB Interactive HTML

`index.html` is for Chrome / Chromium users.
`jsexe.html` is for browsers that do not support [DecompressionStream API](https://developer.mozilla.org/en-US/docs/Web/API/DecompressionStream) (including Firefox).
